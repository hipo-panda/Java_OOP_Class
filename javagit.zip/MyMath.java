public class MyMath {
  int square(int i) {
    return i * i;
  }

  double square(double i) {
    return i * i;
  }
}
