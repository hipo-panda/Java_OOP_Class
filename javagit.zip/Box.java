public class Box {
  int width;
  int lenght;
  int height;
}
